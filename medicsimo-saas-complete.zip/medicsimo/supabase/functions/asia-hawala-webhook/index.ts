/**
 * supabase/functions/asia-hawala-webhook/index.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Supabase Edge Function — AsiaHawala payment webhook receiver.
 *
 * URL: https://<project>.supabase.co/functions/v1/asia-hawala-webhook
 *
 * Environment variables required:
 *   ASIA_HAWALA_WEBHOOK_SECRET — from AsiaHawala merchant portal
 *   SUPABASE_URL               — auto-injected
 *   SUPABASE_SERVICE_ROLE_KEY  — auto-injected
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { serve }        from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verifyHmacSignature, errorResponse, successResponse }
  from "../gateway-shared/verify.js";

const SUBSCRIPTION_PRICE_USD = 25.00;

serve(async (req: Request) => {
  if (req.method !== "POST") return errorResponse("Method not allowed", 405);

  const rawBody     = await req.text();
  const secret      = Deno.env.get("ASIA_HAWALA_WEBHOOK_SECRET") ?? "";
  const receivedSig = req.headers.get("X-Asia-Signature") ?? "";

  const valid = await verifyHmacSignature(rawBody, receivedSig, secret);
  if (!valid) {
    console.error("[asia-hawala] Invalid signature — rejected");
    return errorResponse("Invalid signature", 401);
  }

  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return errorResponse("Invalid JSON body");
  }

  // AsiaHawala payload shape:
  // { ref_id, payment_status: "approved"|"rejected",
  //   amount_iqd, clinic_id }
  const {
    ref_id,
    payment_status,
    amount_iqd,
    clinic_id: clinicId,
  } = payload as {
    ref_id: string;
    payment_status: string;
    amount_iqd: number;
    clinic_id: string;
  };

  if (!clinicId) {
    console.error("[asia-hawala] Missing clinic_id in payload");
    return errorResponse("Missing clinic_id");
  }

  const amountIqd = Number(amount_iqd ?? 0);
  const amountUsd = Math.round((amountIqd / 1310) * 100) / 100;

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  await supabase.rpc("record_gateway_payment", {
    p_clinic_id:   clinicId,
    p_gateway:     "asia_hawala",
    p_gateway_ref: String(ref_id ?? ""),
    p_amount_usd:  amountUsd,
    p_amount_iqd:  amountIqd,
    p_raw_payload: payload,
  });

  if (payment_status === "approved" && amountUsd >= SUBSCRIPTION_PRICE_USD) {
    const { error } = await supabase.rpc("superadmin_activate_clinic", {
      p_clinic_id:      clinicId,
      p_months:         1,
      p_amount_usd:     amountUsd,
      p_payment_method: "asia_hawala",
      p_payment_ref:    String(ref_id ?? ""),
      p_notes:          "Auto-activated via AsiaHawala webhook",
    });
    if (error) console.error("[asia-hawala] activate error:", error.message);
    else console.log(`[asia-hawala] Clinic ${clinicId} activated`);
  }

  return successResponse({ received: true, clinic_id: clinicId });
});

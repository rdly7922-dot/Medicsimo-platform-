/**
 * supabase/functions/qi-card-webhook/index.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Supabase Edge Function — Qi Card / Al-Rafidain payment webhook receiver.
 *
 * URL: https://<project>.supabase.co/functions/v1/qi-card-webhook
 *
 * Environment variables required:
 *   QI_CARD_WEBHOOK_SECRET     — from Qi Card merchant portal
 *   SUPABASE_URL               — auto-injected
 *   SUPABASE_SERVICE_ROLE_KEY  — auto-injected
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { serve }        from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verifyHmacSignature, errorResponse, successResponse }
  from "../gateway-shared/verify.js";

const SUBSCRIPTION_PRICE_USD = 25.00;

serve(async (req: Request) => {
  if (req.method !== "POST") return errorResponse("Method not allowed", 405);

  const rawBody     = await req.text();
  const secret      = Deno.env.get("QI_CARD_WEBHOOK_SECRET") ?? "";
  const receivedSig = req.headers.get("X-Qi-Signature") ?? "";

  const valid = await verifyHmacSignature(rawBody, receivedSig, secret);
  if (!valid) {
    console.error("[qi-card] Invalid signature — rejected");
    return errorResponse("Invalid signature", 401);
  }

  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return errorResponse("Invalid JSON body");
  }

  // Qi Card payload shape:
  // { orderId, transactionStatus: "SUCCESS"|"FAILED",
  //   amount, currency: "IQD", extraData: { clinic_id } }
  const {
    orderId,
    transactionStatus,
    amount,
    extraData,
  } = payload as {
    orderId: string;
    transactionStatus: string;
    amount: number;
    currency: string;
    extraData?: { clinic_id?: string };
  };

  const clinicId = extraData?.clinic_id;
  if (!clinicId) {
    console.error("[qi-card] Missing clinic_id in extraData");
    return errorResponse("Missing clinic_id in extraData");
  }

  const amountIqd = Number(amount ?? 0);
  const amountUsd = Math.round((amountIqd / 1310) * 100) / 100;

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  // Record the transaction regardless of status
  await supabase.rpc("record_gateway_payment", {
    p_clinic_id:   clinicId,
    p_gateway:     "qi_card",
    p_gateway_ref: String(orderId ?? ""),
    p_amount_usd:  amountUsd,
    p_amount_iqd:  amountIqd,
    p_raw_payload: payload,
  });

  // Auto-activate only on successful payment with correct amount
  if (transactionStatus === "SUCCESS" && amountUsd >= SUBSCRIPTION_PRICE_USD) {
    const { error } = await supabase.rpc("superadmin_activate_clinic", {
      p_clinic_id:      clinicId,
      p_months:         1,
      p_amount_usd:     amountUsd,
      p_payment_method: "qi_card",
      p_payment_ref:    String(orderId ?? ""),
      p_notes:          "Auto-activated via Qi Card webhook",
    });
    if (error) console.error("[qi-card] activate error:", error.message);
    else console.log(`[qi-card] Clinic ${clinicId} activated`);
  }

  return successResponse({ received: true, clinic_id: clinicId });
});

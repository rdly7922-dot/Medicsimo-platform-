/**
 * supabase/functions/fib-webhook/index.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Supabase Edge Function — Fast Iraqi Bank (FIB) payment webhook receiver.
 *
 * FIB sends a POST to this URL after every transaction:
 *   https://<project>.supabase.co/functions/v1/fib-webhook
 *
 * Environment variables required:
 *   FIB_WEBHOOK_SECRET         — from FIB merchant portal
 *   SUPABASE_URL               — auto-injected
 *   SUPABASE_SERVICE_ROLE_KEY  — auto-injected
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { serve }        from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verifyHmacSignature, errorResponse, successResponse }
  from "../gateway-shared/verify.js";

const SUBSCRIPTION_PRICE_USD = 25.00;

serve(async (req: Request) => {
  if (req.method !== "POST") return errorResponse("Method not allowed", 405);

  const rawBody     = await req.text();
  const secret      = Deno.env.get("FIB_WEBHOOK_SECRET") ?? "";
  const receivedSig = req.headers.get("X-FIB-Signature") ?? "";

  const valid = await verifyHmacSignature(rawBody, receivedSig, secret);
  if (!valid) {
    console.error("[fib] Invalid signature — rejected");
    return errorResponse("Invalid signature", 401);
  }

  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return errorResponse("Invalid JSON body");
  }

  // FIB payload shape:
  // { paymentId, status: "PAID"|"DECLINED", amount: { amount, currency },
  //   description, metadata: { clinic_id } }
  const {
    paymentId,
    status,
    amount: amountObj,
    metadata,
  } = payload as {
    paymentId: string;
    status: string;
    amount: { amount: number; currency: string };
    metadata?: { clinic_id?: string };
  };

  const clinicId = metadata?.clinic_id;
  if (!clinicId) {
    console.error("[fib] Missing clinic_id in metadata");
    return errorResponse("Missing clinic_id in metadata");
  }

  // FIB uses IQD by default
  const amountIqd = Number(amountObj?.amount ?? 0);
  const amountUsd = Math.round((amountIqd / 1310) * 100) / 100;

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  // Record transaction
  await supabase.rpc("record_gateway_payment", {
    p_clinic_id:   clinicId,
    p_gateway:     "fib",
    p_gateway_ref: String(paymentId ?? ""),
    p_amount_usd:  amountUsd,
    p_amount_iqd:  amountIqd,
    p_raw_payload: payload,
  });

  // Auto-activate on successful payment
  if (status === "PAID" && amountUsd >= SUBSCRIPTION_PRICE_USD) {
    const { error } = await supabase.rpc("superadmin_activate_clinic", {
      p_clinic_id:      clinicId,
      p_months:         1,
      p_amount_usd:     amountUsd,
      p_payment_method: "fib",
      p_payment_ref:    String(paymentId ?? ""),
      p_notes:          "Auto-activated via FIB webhook",
    });
    if (error) console.error("[fib] activate error:", error.message);
    else console.log(`[fib] Clinic ${clinicId} activated`);
  }

  return successResponse({ received: true, clinic_id: clinicId });
});
